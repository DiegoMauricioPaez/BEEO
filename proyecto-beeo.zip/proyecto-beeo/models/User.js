const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
  userId: { type: String, required: true, unique: true },
  consentGiven: { type: Boolean, default: false },
  consentDate: { type: Date },
  createdAt: { type: Date, default: Date.now },
  baselineCalculated: { type: Boolean, default: false },
  baselineData: {
    sleepHours: { type: Object },
    callFrequency: { type: Object },
    locationChanges: { type: Object },
    screenTime: { type: Object }
  }
});

module.exports = mongoose.model('User', UserSchema);