const mongoose = require('mongoose');

const RoutineChangeSchema = new mongoose.Schema({
  userId: { type: String, required: true, index: true },
  detectedAt: { type: Date, required: true, default: Date.now },
  changeType: { 
    type: String, 
    enum: ['sleep_pattern', 'communication_drop', 'location_anomaly', 
           'app_usage_change', 'screen_time_increase', 'social_isolation'],
    required: true 
  },
  severity: { type: String, enum: ['low', 'medium', 'high'] },
  description: String,
  metrics: {
    before: Object,
    after: Object,
    deviation: Number
  },
  notified: { type: Boolean, default: false },
  acknowledged: { type: Boolean, default: false }
});

module.exports = mongoose.model('RoutineChange', RoutineChangeSchema);