const mongoose = require('mongoose');

const SensorDataSchema = new mongoose.Schema({
  userId: { type: String, required: true, index: true },
  timestamp: { type: Date, required: true, index: true },
  
  location: {
    latitude: Number,
    longitude: Number,
    accuracy: Number,
    speed: Number
  },
  
  accelerometer: {
    x: Number,
    y: Number,
    z: Number,
    activity: String
  },
  
  appUsage: [{
    packageName: String,
    appName: String,
    timeSpent: Number,
    startTime: Date,
    category: String
  }],
  
  communication: {
    calls: [{
      type: String,
      duration: Number,
      contactHash: String,
      timestamp: Date
    }],
    messages: [{
      type: String,
      count: Number,
      timestamp: Date
    }]
  },
  
  device: {
    batteryLevel: Number,
    isCharging: Boolean,
    screenOn: Boolean,
    screenBrightness: Number
  },
  
  connectivity: {
    wifiConnected: Boolean,
    bluetoothOn: Boolean,
    mobileDataOn: Boolean
  },
  
  processed: { type: Boolean, default: false },
  anomalies: [String]
});

SensorDataSchema.index({ userId: 1, timestamp: -1 });

module.exports = mongoose.model('SensorData', SensorDataSchema);