const express = require('express');
const mongoose = require('mongoose');
const User = require('./models/User');
const SensorData = require('./models/SensorData');
const RoutineChange = require('./models/RoutineChange');

const app = express();
app.use(express.json());

// CONEXIÓN A MONGODB
mongoose.connect('mongodb://localhost:27017/beeo_db', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => console.log(' Conectado a MongoDB'))
  .catch(err => console.error(' Error:', err));

// ============ API ENDPOINTS ============

// 1. Registrar usuario
app.post('/api/user/register', async (req, res) => {
  const { userId } = req.body;
  try {
    const user = new User({ userId, consentGiven: true, consentDate: new Date() });
    await user.save();
    res.json({ success: true, message: 'Usuario registrado' });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// 2. Guardar datos del móvil
app.post('/api/data/collect', async (req, res) => {
  const { userId, sensorData } = req.body;
  
  try {
    const user = await User.findOne({ userId });
    if (!user || !user.consentGiven) {
      return res.status(401).json({ error: 'Usuario no autorizado' });
    }
    
    const newData = new SensorData({
      userId,
      timestamp: new Date(),
      ...sensorData,
      processed: false
    });
    
    await newData.save();
    res.json({ success: true, dataId: newData._id });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// 3. Obtener datos históricos
app.get('/api/data/:userId', async (req, res) => {
  const { userId } = req.params;
  const { days = 7 } = req.query;
  
  const startDate = new Date();
  startDate.setDate(startDate.getDate() - days);
  
  const data = await SensorData.find({
    userId,
    timestamp: { $gte: startDate }
  }).sort({ timestamp: 1 });
  
  res.json(data);
});

// 4. Obtener cambios detectados
app.get('/api/changes/:userId', async (req, res) => {
  const { userId } = req.params;
  const { severity } = req.query;
  
  const query = { userId };
  if (severity) query.severity = severity;
  
  const changes = await RoutineChange.find(query).sort({ detectedAt: -1 });
  res.json(changes);
});

// 5. Marcar cambio como leído
app.put('/api/changes/:changeId/acknowledge', async (req, res) => {
  await RoutineChange.findByIdAndUpdate(req.params.changeId, { 
    acknowledged: true,
    notified: true
  });
  res.json({ success: true });
});

// 6. Resumen del usuario
app.get('/api/user/summary/:userId', async (req, res) => {
  const user = await User.findOne({ userId: req.params.userId });
  const dataCount = await SensorData.countDocuments({ userId: req.params.userId });
  const changesCount = await RoutineChange.countDocuments({ userId: req.params.userId });
  
  res.json({
    user,
    totalDataPoints: dataCount,
    totalChanges: changesCount
  });
});

// 7. Estadísticas rápidas
app.get('/api/stats', async (req, res) => {
  const totalUsers = await User.countDocuments();
  const totalData = await SensorData.countDocuments();
  const totalChanges = await RoutineChange.countDocuments();
  const highSeverity = await RoutineChange.countDocuments({ severity: 'high' });
  
  res.json({
    totalUsers,
    totalDataPoints: totalData,
    totalChangesDetected: totalChanges,
    highSeverityChanges: highSeverity
  });
});

// INICIAR SERVIDOR
const PORT = 3000;
app.listen(PORT, () => {
  console.log(` Servidor en http://localhost:${PORT}`);
});